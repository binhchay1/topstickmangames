<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php

    global $wpdb;
    $yydev_tags_table_name = $wpdb->prefix . "yydev_tagmanager"; // Database Table Name
    $wp_options_name = "yydev_tagmanager_settings";

?>